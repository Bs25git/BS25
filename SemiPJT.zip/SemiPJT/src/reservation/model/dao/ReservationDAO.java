package reservation.model.dao;

public class ReservationDAO {

}

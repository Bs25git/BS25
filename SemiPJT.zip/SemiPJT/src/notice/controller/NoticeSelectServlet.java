package notice.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import notice.model.service.NoticeService;
import notice.model1.vo.Comment;
import notice.model1.vo.Notice;

/**
 * Servlet implementation class NoticeSelectServlet
 */
@WebServlet("/notice/select")
public class NoticeSelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NoticeSelectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 한 개의 Notice를 DB에서 가져오면 됨
		
		
		// 1. 인코딩 처리
		request.setCharacterEncoding("utf-8");
		// 2. 웹에서 보내주는 데이터에 변수 저장
		int noticeNo = Integer.parseInt(request.getParameter("noticeNo"));
		
		// SELECT * FROM NOTICE WHERE NOTICENO=12;
		Notice notice = new NoticeService().selectNotice(noticeNo);
		Comment comment = new NoticeService().commentRe(noticeNo); 
		
		if (notice != null) {
			request.setAttribute("comment", comment);
			request.setAttribute("content", notice);
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/views/notice/noticeContent2.jsp");
			view.forward(request, response);
		}else {
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/views/notice/noticeError.html");
			view.forward(request, response);
		}
		
		
		
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
